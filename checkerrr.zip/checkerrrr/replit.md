# replit.md

## Overview

This is a simple Node.js/Express web application for collecting and storing numeric data. Users can submit numbers through a web form, which are then persisted to a JSON file and displayed in a list. The application serves as a basic data collection tool with a minimal frontend interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Express.js (v5.2.1) running on Node.js
- **Server Port**: 5000
- **API Design**: Simple REST-style endpoints
  - `POST /enviar` - Accepts numeric string input, validates it contains only digits, and stores it with a timestamp
  - `GET /dados` - Returns all stored entries as JSON array

### Data Storage
- **Storage Method**: File-based JSON storage (`dados.json`)
- **Data Structure**: Array of objects with `numeros` (string of digits) and `data` (ISO timestamp)
- **Rationale**: Simple persistence without database setup overhead; suitable for low-volume data collection
- **Trade-off**: Not suitable for concurrent writes or large datasets; no query capabilities

### Frontend Architecture
- **Type**: Static HTML served from `/public` directory
- **Styling**: Inline CSS, minimal design
- **JavaScript**: Vanilla JS with async/fetch for API communication
- **Features**: Form submission and dynamic list display of saved entries

### Input Validation
- Server-side regex validation ensures only numeric strings are accepted (`/^[0-9]+$/`)
- Returns 400 error for invalid input

## External Dependencies

### NPM Packages
- **express (^5.2.1)**: Web server framework - handles routing, middleware, and static file serving
- **@types/node (^22.13.11)**: TypeScript type definitions for Node.js (though project uses JavaScript)

### File System
- Uses Node.js built-in `fs` module for reading/writing `dados.json`
- No external database required

### No External Services
- Application is self-contained with no third-party API integrations
- No authentication system implemented